package com.example.spacetrader.dataaccess.repositories;

public class UniverseRepository {


}
