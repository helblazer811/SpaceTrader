package com.example.spacetrader.views;

import android.app.Activity;

public class SettingsActivity extends Activity {
}
