package com.example.spacetrader.dataaccess;

public enum StorageMode {
    ROOM,
    FIREBASE;
}
