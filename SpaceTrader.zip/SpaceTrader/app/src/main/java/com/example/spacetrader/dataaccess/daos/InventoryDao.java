package com.example.spacetrader.dataaccess.daos;

public interface InventoryDao {
}
