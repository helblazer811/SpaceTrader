package com.example.spacetrader.dataaccess.repositories;

public class Repository {

    /*
        This is an inner class so that Room can be
        asynchronously run in a background thread.
     */

}

