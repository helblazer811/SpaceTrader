package com.example.spacetrader.dataaccess.firebase;

import com.example.spacetrader.entities.Player;

public class FirebaseStorage {

    public Player loadPlayer() {
        return null;
    }

    public void insertPlayer(Player player) {

    }
}
